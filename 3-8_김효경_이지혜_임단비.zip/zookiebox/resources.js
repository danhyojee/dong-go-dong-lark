var Images = {
      Loading : [new Image(), new Image(), new Image(), new Image()],
      UI : [new Image(), new Image(), new Image, new Image(), new Image(), new Image(), new Image(), new Image()],
      pet : {
            dog : [new Image(), new Image(), new Image(), new Image(), new Image(), new Image()],
            cat : [new Image(), new Image(), new Image(), new Image(), new Image(), new Image()],
            rabbit : [new Image(), new Image(), new Image(), new Image(), new Image(), new Image()],
            hamster : [new Image(), new Image(), new Image(), new Image(), new Image(), new Image()]
      },
      predator : {
            bear : [new Image(), new Image(), new Image(), new Image(), new Image(), new Image()],
            lion : [new Image(), new Image(), new Image(), new Image(), new Image(), new Image()],
            elegator : [new Image(), new Image(), new Image(), new Image(), new Image(), new Image()],
            ptero : [new Image(), new Image(), new Image(), new Image(), new Image(), new Image()]
      },
      bird : {
            peacock : [new Image(), new Image(), new Image(), new Image(), new Image(), new Image()],
            crow : [new Image(), new Image(), new Image(), new Image(), new Image(), new Image()],
            owl : [new Image(), new Image(), new Image(), new Image(), new Image(), new Image()],
            sparraw : [new Image(), new Image(), new Image(), new Image(), new Image(), new Image()]
      },
      marine : {
            dolphin : [new Image(), new Image(), new Image(), new Image(), new Image(), new Image()],
            clam : [new Image(), new Image(), new Image(), new Image(), new Image(), new Image()],
            hippo : [new Image(), new Image(), new Image(), new Image(), new Image(), new Image()],
            jelly : [new Image(), new Image(), new Image(), new Image(), new Image(), new Image()]
      }
};
var Audios = {
      beat : [new Audio(), new Audio(), new Audio(), new Audio()],
      instrument : [new Audio(), new Audio(), new Audio(), new Audio()],
      melody : [new Audio(), new Audio(), new Audio(), new Audio()],
      voice : [new Audio(), new Audio(), new Audio(), new Audio()],
}
var syncAudio = new Audio("Sounds/beat/beat1_1.wav");
var loadResources = function()
{
      for(var i=0;i<4;i++)
      {
            for(folder in Images)
            {
                  if(folder == "Loading" || folder == "UI")
                  {
                        Images[folder][i].src = "Images/" + folder + "/" + folder + i +".png";
                        if(i==3 && folder == "UI")
                        {
                              Images[folder][4].src = "Images/" + folder + "/" + folder + "4.png";
                              Images[folder][5].src = "Images/" + folder + "/" + folder + "5.png";
                              Images[folder][6].src = "Images/" + folder + "/" + folder + "6.png";
                              Images[folder][7].src = "Images/" + folder + "/" + folder + "7.png";
                        }
                  }
                  else
                  {
                        for(folder2 in Images[folder])
                        {
                              Images[folder][folder2][i].src = "Images/"+folder+"/"+folder2+"/"+folder2+(i+1)+".png";
                              if(i==3)
                              {
                                    Images[folder][folder2][4].src = "Images/"+folder+"/icon/"+folder2+".png";
                                    Images[folder][folder2][5].src = "Images/"+folder+"/icon/"+folder2+"_g.png";
                              }
                        }
                  }
            }

      }
      for(folder in Audios)
      {
            var count = 1;
            for(audio in Audios[folder])
            {
                  Audios[folder][audio].src = "Sounds/" + folder + "/" + folder + (count++) + "_1.wav";
                  Audios[folder][audio].preload = "metadata";
                  Audios[folder][audio].loop = true;
                  Audios[folder][audio].load();
                  Audios[folder][audio].canplaythrough = canPlayThrough;
            }
      }
      var count = 0;
      for(folder1 in Images)
      {
            if(folder1 != "Loading" && folder1 != "UI")
            {
                  for(folder2 in Images[folder1])
                  {
                        Animals.push(new Animal(folder1,folder2,Animals.length));
                        Animals[count].sound = Audios[["beat","instrument","melody","voice"][parseInt(count/4)]][count % 4];
                        count ++;
                  }
            }
      }
      syncAudio.loop = true;
      syncAudio.volume = 0;
      syncAudio.play();
      syncAudio.onplaying = playAll;
      //AudioTest();
      draw();
}
var canPlayThrough = function()
{
      AudioCount++;
}
var AudioCount = 0;
var isResourcesAllLoaded = function()
{
      for(folder in Images)
      {
            for(folder2 in Images[folder])
            {
                  if(folder == "Loading" || folder == "UI")
                  {
                        if(!Images[folder][folder2].complete)
                              return false;
                  }
                  else
                  {
                        for(var i=0;i<5;i++)
                        {
                              if(!Images[folder][folder2][i].complete)
                                    return false;
                        }
                  }
            }
      }
      for(folder in Audios)
      {
            for(audio in Audios[folder])
            {
                  if(Audios[folder][audio].readyState != 4)
                  {
                        //Audios[folder][audio].load();
                        return false;
                  }
            }
      }
      return true;
}
var AudioTest = function()
{
      for(folder in Audios)
      {
            for(audio in Audios[folder])
            {
                  Audios[folder][audio].play();
            }
      }
}