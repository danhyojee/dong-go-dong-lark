var canvas = document.getElementById('canvas');
var ctx = canvas.getContext('2d');
var rand = function(n,m)
{
      if(m)
            return parseInt(Math.random() * 1000000) % parseInt(m-n+1) + parseInt(n);
      else
            return parseInt(Math.random() * 1000000) % parseInt(n);
}
var drawImageWithSize = function(image,x,y,width,height)
{
      if(height != undefined || height != null)
            ctx.drawImage(image,0,0,image.width,image.height,x-width/2,y-height/2,width,height);
      else
            ctx.drawImage(image,0,0,image.width,image.height,x-width/2,y-(width / image.width * image.height)/2, width, width / image.width * image.height);
}
var drawFilledRect = function(x,y,w,h)
{
      if(h)
            ctx.fillRect(x - w / 2, y - h / 2, w, h);
      else
            ctx.fillRect(x - w / 2, y - w / 2, w, w);
}
var isPointInImageSize = function(px,py,x,y,w,h)
{
      return ((px >= (x - w/2)) && (px <= (x + w/2)) && (py >= (y - h/2)) && (py <= (y + h/2)));
}
var clean0Array = function(arr)
{
      arr.sort();
      for(var i=0;i<arr.length;i++)
      {
            if(arr[i] == 0)
            {
                  arr[i] = arr[arr.length-1];
                  arr.pop();
                  i = 0;
            }
      }
}
var clearArray = function(arr)
{
      for(var i=0;i<arr.length;)
            arr.pop();
}
var waitFuncArray = [];
var wait = function(func,f)
{
      waitFuncArray.push([frame + f,func]);
}
var isOverlapArr = function(arr,i)
{
      for(var j = 0;j<i;j++)
      {
            if(arr[j] == arr[i])
                  return true;
      }
      return false;
}
var animateAnimals = function (folder1,folder2,x,y,w,h)
{
      if(frame % 40 < 10)
      {
            drawImageWithSize(Images[folder1][folder2][0],x,y,w,h);
      }
      else if(frame % 40 < 20)
      {
            drawImageWithSize(Images[folder1][folder2][1],x,y,w,h);
      }
      else if(frame % 40 < 30)
      {
            drawImageWithSize(Images[folder1][folder2][2],x,y,w,h);
      }
      else
      {
            drawImageWithSize(Images[folder1][folder2][3],x,y,w,h);
      }
}
var loading = function()
{
      ctx.fillStyle = "black";
      ctx.fillRect(0,0,canvas.width,canvas.height);
      if(frame % 60 < 15)
            drawImageWithSize(Images.Loading[0],canvas.width/2,canvas.height/2,canvas.height/8 / Images.Loading[0].height * Images.Loading[0].width);
      else if(frame % 60 < 30)
            drawImageWithSize(Images.Loading[1],canvas.width/2,canvas.height/2,canvas.height/8 / Images.Loading[1].height * Images.Loading[1].width);
      else if(frame % 60 < 45)
            drawImageWithSize(Images.Loading[2],canvas.width/2,canvas.height/2,canvas.height/8 / Images.Loading[2].height * Images.Loading[2].width);
      else
            drawImageWithSize(Images.Loading[3],canvas.width/2,canvas.height/2,canvas.height/8 / Images.Loading[3].height * Images.Loading[3].width);
}
var isPlayOnly = function(n)
{
      for(var i=0;i<8;i++)
      {
            if(onViewAnimals[i])
            {
                  if(i == n)
                  {
                        if(onViewAnimals[i].mute)
                              return false;
                  }
                  else
                  {
                        if(!onViewAnimals[i].mute)
                              return false;
                  }
            }
      }
      return true;
}
var playOnly = function(n)
{
      if(isPlayOnly(n))
      {
            unMuteAll();
            return 0;
      }
      for(var i=0;i<8;i++)
      {
            if(onViewAnimals[i] != null)
            {
                  if(i == n)
                  {
                        onViewAnimals[i].mute = false;
                  }
                  else
                  {
                        onViewAnimals[i].mute = true;
                  }
            }
      }
      setMute();
}
var isAllMute = function()
{
      for(var i=0;i<8;i++)
      {
            if(onViewAnimals[i])
            {
                  if(!onViewAnimals[i].mute)
                        return false;
            }
      }
      return true;
}
var muteAll = function()
{
      for(var i=0;i<8;i++)
      {
            if(onViewAnimals[i])
            {
                  onViewAnimals[i].mute = true;
            }
      }
      setMute();
}
var unMuteAll = function()
{
      for(var i=0;i<8;i++)
      {
            if(onViewAnimals[i])
            {
                  onViewAnimals[i].mute = false;
            }
      }
      setMute();
}
var deleteAll = function()
{
      for(var i=0;i<8;i++)
      {
            if(onViewAnimals[i])
            {
                  onViewAnimals[i].menu_enabled = false;
                  onViewAnimals[i].mute = false;
                  onViewAnimals[i].onView = false;
                  onViewAnimals[i] = null;
            }
      }
      setMute();
}
var shuffle = function()
{
      for(var i=0;i<8;i++)
      {
            if(onViewAnimals[i])
            {
                  onViewAnimals[i].mute = false;
                  onViewAnimals[i].onView = false;
                  onViewAnimals[i] = null;
            }
            var rn;
            do {
                  rn = rand(Animals.length);
            } while(Animals[rn].onView)
            onViewAnimals[i] = Animals[rn];
            onViewAnimals[i].onView = true;
      }
}
var playAll = function()
{
      for(var i=0;i<16;i++)
      {
            if(Animals[i])
            {
                  Animals[i].sound.currentTime = 0;
                  Animals[i].sound.play();
                  if(Animals[i].onView && !Animals[i].mute)
                  {
                        Animals[i].sound.volume = 1;
                  }
                  else
                  {
                        Animals[i].sound.volume = 0;
                  }
            }
      }
      rotation = 0;
}
var setMute = function()
{
      for(var i=0;i<16;i++)
      {
            if(Animals[i])
            {
                  if(Animals[i].onView && !Animals[i].mute)
                  {
                       Animals[i].sound.volume = 1;
                  }
                  else
                  {
                        Animals[i].sound.volume = 0;
                  }
            }
      }
}
var addZero = function(n)
{
      return n < 10 ? "0" + n : n.toString();
}
var load = function(n)
{
      for(var i=0;i<8;i++)
      {
            onViewAnimals[i] = null;
      }
      for(var i=0;i<16;i++)
      {
            Animals[i].onView = false;
            Animals[i].mute = false;
            Animals[i].sound.volume = 0;
      }
      var arr = localStorage["zb" + n].substr(localStorage["zb" + n].indexOf(";")+1).split(",");
      for(var i=0;i<8;i++)
      {
            if(arr[i] != -1)
            {
                  onViewAnimals[i] = Animals[parseInt(arr[i])];
                  onViewAnimals[i].onView = true;
            }
      }
}
var video;
var makingVideo = false;
var videoFrame = null;
var startVideo = function()
{
      video = new Whammy.Video(10);
      makingVideo = true;
      videoFrame = frame;
}
var endVideo = function()
{
      makingVideo = false;
      var output = video.compile();
      var url = webkitURL.createObjectURL(output);
      console.log(url);
}
var share = function()
{
      FB.getLoginStatus(function(response) {
            if(response.status != 'connected')
            {
                  FB.login(function(response){});
                  setTimeout(shareFB,1000);
            }
            else
            {
                  shareFB();
            }
      });
}
