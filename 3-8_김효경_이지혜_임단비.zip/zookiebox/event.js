var onLoad = function()
{
      if(ctx)
      {
            if(navigator.userAgent.match(/Android|Mobile|iP(hone|od|ad)|BlackBerry|IEMobile|Kindle|NetFront|Silk-Accelerated|(hpw|web)OS|Fennec|Minimo|Opera M(obi|ini)|Blazer|Dolfin|Dolphin|Skyfire|Zune/))
            {
                  window.addEventListener("touchstart",onMouseDown,false);
                  window.addEventListener("touchmove",onMouseMove,false);
                  window.addEventListener("touchend",onMouseUp,false);
                  window.addEventListener("touchcancel",onMouseUp,false);
            }
            else
            {
                  onmousedown = onMouseDown;
                  onmouseup = onMouseUp;
                  onmousemove = onMouseMove;
            }
            onresize();
            loadResources();
      }
      else
            document.getElementsByTagName('font')[0].style.opacity = 255;
}
var onresize = function()
{
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      /*
      if(window.innerHeight / 4 * 3 > window.innerWidth)
      {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            canvas.style.left = 0;
      }
      else
      {
            canvas.height = window.innerHeight;
            canvas.width = parseInt(canvas.height * 3 / 4);
            canvas.style.left = (window.innerWidth - canvas.width) / 2;
      }
      scale2 = - canvas.width * 1.2;
      */
}
var onMouseDown = function(event)
{
      var Mouse;
      if(event)
      {
            if(navigator.userAgent.match(/Android|Mobile|iP(hone|od|ad)|BlackBerry|IEMobile|Kindle|NetFront|Silk-Accelerated|(hpw|web)OS|Fennec|Minimo|Opera M(obi|ini)|Blazer|Dolfin|Dolphin|Skyfire|Zune/))
            {
                  Mouse = {
                      X: event.touches[0].pageX - parseInt(canvas.style.left),
                      Y: event.touches[0].pageY
                  }
            }
            else
            {
                  Mouse = {
                      X: event.pageX - parseInt(canvas.style.left),
                      Y: event.pageY
                  }
            }
      }
      MouseX = Mouse.X;
      MouseY = Mouse.Y;
      if(saving)
      {
            var saveWindow = {
                  x : canvas.width / 2 - 300,
                  y : canvas.height / 2 - 250,
                  w : 600,
                  h : 500
            }
            for(var i=0;i<5;i++)
            {
                  if( Mouse.X >= saveWindow.x + 10 + saveWindow.w - 200 + 10 + 9 && Mouse.X <= saveWindow.x + 10 + saveWindow.w - 200 + 10 + 79 &&
                        Mouse.Y >= saveWindow.y + 10 + 98 * i + 9 && Mouse.Y <= saveWindow.y + 10 + 98 * i + 79)
                  {
                        var d = new Date();
                        var date = "";
                        date += d.getFullYear() + "/";
                        date += addZero(d.getMonth()) + "/";
                        date += addZero(d.getDate()) + " ";
                        date += addZero(d.getHours()) + ":"
                        date += addZero(d.getMinutes()) + ":"
                        date += addZero(d.getSeconds());
                        var text = "";
                        for(var j=0;j<8;j++)
                        {
                              if(onViewAnimals[j])
                              {
                                    text += onViewAnimals[j].number.toString();
                              }
                              else
                              {
                                    text += "-1";
                              }
                              if(j!=7)
                              {
                                    text += ",";
                              }
                        }
                        localStorage["zb" + i] = date + ";" + text;
                        return true;
                  }
                  else if( Mouse.X >= saveWindow.x + 10 + saveWindow.w - 200 + 10 + 9 + 88 && Mouse.X <= saveWindow.x + 10 + saveWindow.w - 200 + 10 + 79 + 88 &&
                        Mouse.Y >= saveWindow.y + 10 + 98 * i + 9 && Mouse.Y <= saveWindow.y + 10 + 98 * i + 79)
                  {
                        localStorage["zb" + i] = "";
                        return true;
                  }
                  else if(Mouse.X >= saveWindow.x + 10 && Mouse.X <= saveWindow.x + 10 + saveWindow.w - 200 && Mouse.Y >= saveWindow.y + 10 + 98 * i && Mouse.Y <= saveWindow.y + 10 + 98 * i + 88)
                  {
                        load(i);
                        return true;
                  }
            }
            if(Mouse.X <= saveWindow.x || Mouse.X >= saveWindow.x + saveWindow.w || Mouse.Y <= saveWindow.y || Mouse.Y >= saveWindow.y + saveWindow.h)
            {
                  saving = false;
            }
      }
      else
      {
            for(var i=0;i<16;i++)
            {
                  var x = i * drawArea.w / 8 / animationWidth * iconSize + (drawArea.w / 8 / animationWidth * iconSize/2);
                  var y = drawArea.y + drawArea.h * (controlBar + animationHeight)/t_h + (drawArea.w / 8 /animationWidth * iconSize/2);
                  var r = drawArea.w / 8 / animationWidth * iconSize * 0.9;
                  if(!Animals[i].onView)
                  {
                        if(Mouse.X >= x - r/2 && Mouse.X <= x + r/2 && Mouse.Y >= y - r/2 && Mouse.Y <= y + r/2)
                        {
                              MouseX = Mouse.X;
                              MouseY = Mouse.Y;
                              animalHandle = Animals[i];
                              Animals[i].onView = true;
                        }
                  }
            }
            if(animalHandle == null)
            {
                  for(var i=0;i<8;i++)
                  {
                        var x = drawArea.x + drawArea.w / 8 * i + drawArea.w / 32 * 0.1 ;
                        var y = drawArea.y + drawArea.h * controlBar / t_h + drawArea.w / 32 * 0.1 ;
                        var w = drawArea.w / 32 * 0.8;
                        var h = drawArea.w / 32 * 0.8;
                        if(MouseX >= x + drawArea.w / 32 && MouseX <= x + drawArea.w / 32 + w && MouseY >= y && MouseY <= y + h)
                        {
                              if(onViewAnimals[i] != null)
                              {
                                    if(onViewAnimals[i].menu_enabled)
                                    {
                                          playOnly(i);
                                    }
                              }
                        }
                        if(MouseX >= x + drawArea.w / 32 * 2 && MouseX <= x + drawArea.w / 32 * 2 + w && MouseY >= y && MouseY <= y + h)
                        {
                              if(onViewAnimals[i] != null)
                              {
                                    if(onViewAnimals[i].menu_enabled)
                                    {
                                          if(onViewAnimals[i].mute)
                                          {
                                                onViewAnimals[i].mute = false;
                                          }
                                          else
                                          {
                                                onViewAnimals[i].mute = true;
                                          }
                                          setMute();
                                    }
                              }
                        }
                        if(MouseX >= x + drawArea.w / 32 * 3 && MouseX <= x + drawArea.w / 32 * 3 + w && MouseY >= y && MouseY <= y + h)
                        {
                              if(onViewAnimals[i] != null)
                              {
                                    if(onViewAnimals[i].menu_enabled)
                                    {
                                          onViewAnimals[i].menu_enabled = false;
                                          onViewAnimals[i].mute = false;
                                          onViewAnimals[i].onView = false;
                                          onViewAnimals[i] = null;
                                          setMute();
                                    }
                              }
                        }
                  }
                  for(var i=2;i<=4;i++)
                  {
                        var x = drawArea.x + drawArea.w - (drawArea.h * controlBar / t_h) * i + (drawArea.h * controlBar / t_h) / 2;
                        var y = drawArea.y + drawArea.h * controlBar / t_h / 2;
                        var r = drawArea.h * controlBar / t_h * 0.8;
                        if(MouseX >= x - r/2 && MouseX <= x + r/2 && MouseY >= y - r/2 && MouseY <= y + r/2)
                        {
                              if(i == 2)
                              {
                                    shuffle();
                              }
                              else if(i==3)
                              {
                                    if(isAllMute())
                                    {
                                          unMuteAll();
                                    }
                                    else
                                    {
                                          muteAll();
                                    }
                              }
                              else if(i==4)
                              {
                                    deleteAll();
                              }
                        }
                  }
                  for(var i=0;i<2;i++)
                  {
                        var x = drawArea.x + (drawArea.h * controlBar / t_h) * i + (drawArea.h * controlBar / t_h) / 2;
                        var y = drawArea.y + drawArea.h * controlBar / t_h / 2;
                        var r = drawArea.h * controlBar / t_h * 0.8;
                        if(MouseX >= x - r/2 && MouseX <= x + r/2 && MouseY >= y - r/2 && MouseY <= y + r/2)
                        {
                              if(i==0)
                              {
                                    saving = true;
                              }
                              else if(i==1)
                              {
                                    share();
                              }
                        }
                  }
            }
      }
}
var onMouseUp = function(event)
{
      var Mouse;
      if(event)
      {
            if(navigator.userAgent.match(/Android|Mobile|iP(hone|od|ad)|BlackBerry|IEMobile|Kindle|NetFront|Silk-Accelerated|(hpw|web)OS|Fennec|Minimo|Opera M(obi|ini)|Blazer|Dolfin|Dolphin|Skyfire|Zune/))
            {
                  Mouse = {
                      X: event.touches[0].pageX - parseInt(canvas.style.left),
                      Y: event.touches[0].pageY
                  }
            }
            else
            {
                  Mouse = {
                      X: event.pageX - parseInt(canvas.style.left),
                      Y: event.pageY
                  }
            }
      }
      MouseX = Mouse.X;
      MouseY = Mouse.Y;
      if(animalHandle != null)
      {
            for(var i=0;i<8;i++)
            {
                  var x = drawArea.x + drawArea.w/8 * i;
                  var y = drawArea.y + drawArea.h * controlBar / t_h;
                  var w = drawArea.w/8;
                  var h = drawArea.h * animationHeight/t_h;
                  if(MouseX >= x && MouseX <= x + w && MouseY >= y && MouseY <= y + h)
                  {
                        if(onViewAnimals[i] == null)
                        {
                              onViewAnimals[i] = animalHandle;
                              animalHandle = null;
                        }
                        else
                        {
                              onViewAnimals[i].onView = false;
                              onViewAnimals[i] = animalHandle;
                              animalHandle = null;
                        }
                  }
            }
            if(MouseX < 0 || MouseX > drawArea.x + drawArea.w || MouseY < drawArea.y + drawArea.h * controlBar / t_h || MouseY > drawArea.y + drawArea.h * (controlBar + animationHeight)/t_h)
            {
                  animalHandle.onView = false;
                  animalHandle = null;
            }
      }
}
var onMouseMove = function(event)
{
      var Mouse;
      if(event)
      {
            if(navigator.userAgent.match(/Android|Mobile|iP(hone|od|ad)|BlackBerry|IEMobile|Kindle|NetFront|Silk-Accelerated|(hpw|web)OS|Fennec|Minimo|Opera M(obi|ini)|Blazer|Dolfin|Dolphin|Skyfire|Zune/))
            {
                  Mouse = {
                      X: event.touches[0].pageX - parseInt(canvas.style.left),
                      Y: event.touches[0].pageY
                  }
            }
            else
            {
                  Mouse = {
                      X: event.pageX - parseInt(canvas.style.left),
                      Y: event.pageY
                  }
            }
      }
      MouseX = Mouse.X;
      MouseY = Mouse.Y;
      if(animalHandle == null)
      {
            for(var i=0;i<8;i++)
            {
                  var x = drawArea.x + drawArea.w/8 * i;
                  var y = drawArea.y + drawArea.h * controlBar / t_h;
                  var w = drawArea.w / 8;
                  var h = drawArea.h * animationHeight / t_h;
                  if(MouseX >= x && MouseX <= x + w && MouseY >= y && MouseY <= y + h)
                  {
                        if(onViewAnimals[i] != null)
                        {
                              onViewAnimals[i].menu_enabled = true;
                        }
                  }
                  else
                  {
                        if(onViewAnimals[i] != null)
                        {
                              onViewAnimals[i].menu_enabled = false;
                        }
                  }
            }
      }
}