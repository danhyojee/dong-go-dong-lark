package com.wikitude.samples;

/**
 * Created by danbi on 2017-08-19.
 */


import android.app.Activity;
import android.app.ProgressDialog;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import com.wikitude.sdksamples.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;



import static android.content.ContentValues.TAG;

/**
 * Created by KDH on 2017-08-17.
 */

public class
ListActivity extends Activity
{
    private ListView listView;
    private ListAdapter adapter;
    phpInsert task_insert;

    private static final String TAG_JSON="webnautes";
    private static final String TAG_INDEX = "id";
    private static final String TAG_NAME = "name";
    private static final String TAG_STATUS ="status";
    private static final String TAG_PUZZLE ="puzzle";
    int[] piece;
    String[] name;
    int[] image= {R.drawable.bear,
            R.drawable.cat,
            R.drawable.clam,
            R.drawable.crow,
            R.drawable.dog,
            R.drawable.dolphin,
            R.drawable.elegator,
            R.drawable.hamster,
            R.drawable.hippo,
            R.drawable.jelly,
            R.drawable.lion,
            R.drawable.owl,
            R.drawable.peacock,
            R.drawable.ptero,
            R.drawable.rabbit,
            R.drawable.sparraw};


    String mJsonString;
    private TextView mTextViewResult;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        mTextViewResult = (TextView)findViewById(R.id.textView_main_result);

        GetData task = new GetData();

        task.execute("http://eksql2148.cafe24.com/get.php");



        /*adapter.addItem(ContextCompat.getDrawable(this, R.drawable.cat), "고양이", null, null, it, it, it);
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.clam), "조개", it, it, it, it, it);
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.crow), "까마귀", null, null, null, it, it);
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.dog), "강아지", null, null, null, null, it);
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.dolphin), "돌고래", null, it, it, it, it);
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.elegator), "악어", it, it, it, it, it);
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.hamster), "햄스터", null, it, it, it, it);
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.hippo), "해마", null, null, it, it, it);
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.jelly), "해파리", null, null, it, it, it);
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.lion), "사자", null, null, null, it, it);
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.owl), "부엉이", null, null, null, null, it);
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.peacock), "공작", null, it, it, it, it);
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.ptero), "익룡", null, null, it, it, it);
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.rabbit), "토끼", null, null, null, it, it);
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.sparraw), "참새", null, null, it, it, it);
        */

    }

    private class GetData extends AsyncTask<String, Void, String> {
        ProgressDialog progressDialog;
        String errorString = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog = ProgressDialog.show(ListActivity.this,
                    "Please Wait", null, true, true);
        }


        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            progressDialog.dismiss();
            mTextViewResult.setText(result);
            Log.d(TAG, "response  - " + result);

            if (result == null){

                mTextViewResult.setText(errorString);
            }
            else {

                mJsonString = result;
                showResult();
            }
        }


        @Override
        protected String doInBackground(String... params) {

            String serverURL = params[0];

            try {
                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.connect();

                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    inputStream = httpURLConnection.getErrorStream();
                }


                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "EUC-KR");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }


                bufferedReader.close();


                return sb.toString().trim();


            } catch (Exception e) {

                Log.d(TAG, "InsertData: Error ", e);
                errorString = e.toString();

                return null;
            }

        }
    }


    private void showResult(){
        try {
            JSONObject jsonObject = null;
            Drawable it = ContextCompat.getDrawable(this, R.drawable.marker_idle);
            try {
                jsonObject = new JSONObject(mJsonString);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            JSONArray jsonArray = jsonObject.getJSONArray(TAG_JSON);

            piece = new int[jsonArray.length()];
            name = new String[jsonArray.length()];





            for(int i=0;i<jsonArray.length();i++){

                JSONObject item = jsonArray.getJSONObject(i);

                String index = item.getString(TAG_INDEX);
                String names = item.getString(TAG_NAME);
                String status = item.getString(TAG_STATUS);
                int number = item.getInt(TAG_PUZZLE);

                name[i]=names;
                piece[i]=number;

            }

            adapter = new ListAdapter();
            listView = (ListView) findViewById(R.id.listview);


            for(int i=0;i<piece.length;i++){
                adapter.addItem(ContextCompat.getDrawable(this,image[i]),name[i],piece[i],it);
            }

            listView.setAdapter(adapter);


            listView.setOnItemClickListener(new AdapterView.OnItemClickListener()
            {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l)
                {
                    if(adapter.getPuzzleItemInCheck(i))
                    {
                        task_insert = new phpInsert();

                        String a = adapter.getName(i);

                        task_insert.execute("http://eksql2148.cafe24.com/set.php?name=" + a);

                        Toast.makeText(ListActivity.this, a+" 퍼즐완성!!", Toast.LENGTH_LONG).show();

                        adapter.removeItemData(i);
                        adapter.notifyDataSetChanged();
                    }
                }
            });



        } catch (JSONException e) {

            Log.d(TAG, "showResult : ", e);
        }

    }

    private class phpInsert extends AsyncTask<String, Integer,String>{

        @Override
        protected String doInBackground(String... urls) {
            StringBuilder resultText = new StringBuilder();
            try{
                // 연결 url 설정
                URL url = new URL(urls[0]);
                // 커넥션 객체 생성
                HttpURLConnection conn = (HttpURLConnection)url.openConnection();
                // 연결되었으면.
                if(conn != null){
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);
                    // 연결되었음 코드가 리턴되면.
                    if(conn.getResponseCode() == HttpURLConnection.HTTP_OK){
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        for(;;){
                            // 웹상에 보여지는 텍스트를 라인단위로 읽어 저장.
                            String line = br.readLine();
                            if(line == null) break;
                            // 저장된 텍스트 라인을 jsonHtml에 붙여넣음
                            resultText.append(line);
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch(Exception ex){
                ex.printStackTrace();
            }
            return resultText.toString();

        }

        protected void onPostExecute(String str){
            if(str.equals("1")){
                Toast.makeText(getApplicationContext(),"DB Insert Failed.",Toast.LENGTH_LONG).show();
            }else{
                //Toast.makeText(getApplicationContext(),"DB Insert Success.",Toast.LENGTH_LONG).show();
            }

        }

    }
}