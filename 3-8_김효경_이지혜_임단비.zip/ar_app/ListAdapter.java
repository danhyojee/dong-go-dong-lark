package com.wikitude.samples;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.wikitude.sdksamples.R;

import java.util.ArrayList;

/**
 * Created by KDH on 2017-08-17.
 */

public class ListAdapter extends BaseAdapter
{
    // Adapter에 추가된 데이터를 저장하기 위한 ArrayList
    private ArrayList<ListViewItem> listViewItemList = new ArrayList<ListViewItem>();

    public ListAdapter()
    {
    }

    @Override
    public int getCount()
    {
        return listViewItemList.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        final int pos = position;
        final Context context = parent.getContext();

        if(convertView == null)
        {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.listview_item, parent, false);
        }

        ImageView iconImageView = (ImageView) convertView.findViewById(R.id.list_icon);
        TextView titleTextView = (TextView) convertView.findViewById(R.id.list_txt);

        ImageView iconSubImageView1 = (ImageView) convertView.findViewById(R.id.list_iconSub1);
        ImageView iconSubImageView2 = (ImageView) convertView.findViewById(R.id.list_iconSub2);
        ImageView iconSubImageView3 = (ImageView) convertView.findViewById(R.id.list_iconSub3);
        ImageView iconSubImageView4 = (ImageView) convertView.findViewById(R.id.list_iconSub4);
        ImageView iconSubImageView5 = (ImageView) convertView.findViewById(R.id.list_iconSub5);

        ListViewItem listViewItem = listViewItemList.get(position);

        iconImageView.setImageDrawable(listViewItem.getIcon());
        iconSubImageView1.setImageDrawable(listViewItem.getSubIcon1());
        iconSubImageView2.setImageDrawable(listViewItem.getSubIcon2());
        iconSubImageView3.setImageDrawable(listViewItem.getSubIcon3());
        iconSubImageView4.setImageDrawable(listViewItem.getSubIcon4());
        iconSubImageView5.setImageDrawable(listViewItem.getSubIcon5());
        titleTextView.setText(listViewItem.getTitle());

        return convertView;
    }

    public boolean getPuzzleItemInCheck(int position) //퍼즐조각이 5개가 모두 있는지 확인하는 함수
    //실제로는, 퍼즐이 들어가는 이미지자리에 퍼즐이미지가 다 들어가있는지 확인하는 함수
    {
        boolean check = (listViewItemList.get(position).getSubIcon1() != null) &&
                (listViewItemList.get(position).getSubIcon2() != null) &&
                (listViewItemList.get(position).getSubIcon3() != null) &&
                (listViewItemList.get(position).getSubIcon4() != null) &&
                (listViewItemList.get(position).getSubIcon5() != null);
        return check;
    }

    public void removeItemData(int position) //퍼즐이미지 공간을 모두 null로 만들어 퍼즐이미지를 없애는 함수
    {
        listViewItemList.get(position).setSubIcon1(null);
        listViewItemList.get(position).setSubIcon2(null);
        listViewItemList.get(position).setSubIcon3(null);
        listViewItemList.get(position).setSubIcon4(null);
        listViewItemList.get(position).setSubIcon5(null);
    }

    public String getName(int position){
        String a= listViewItemList.get(position).getTitle();
        return a;
    }


    @Override
    public long getItemId(int position)
    {
        return position;
    }

    @Override
    public Object getItem(int position)
    {
        return listViewItemList.get(position);
    }

    public void addItem(Drawable icon, String title, int i,Drawable it)
    {
        ListViewItem item = new ListViewItem();

        item.setIcon(icon);
        item.setTitle(title);

        switch(i){
            case 0:
                item.setSubIcon1(null);
                item.setSubIcon2(null);
                item.setSubIcon3(null);
                item.setSubIcon4(null);
                item.setSubIcon5(null);
                break;

            case 1:
                item.setSubIcon1(null);
                item.setSubIcon2(null);
                item.setSubIcon3(null);
                item.setSubIcon4(null);
                item.setSubIcon5(it);
                break;

            case 2:
                item.setSubIcon1(null);
                item.setSubIcon2(null);
                item.setSubIcon3(null);
                item.setSubIcon4(it);
                item.setSubIcon5(it);
                break;
            case 3:
                item.setSubIcon1(null);
                item.setSubIcon2(null);
                item.setSubIcon3(it);
                item.setSubIcon4(it);
                item.setSubIcon5(it);
                break;
            case 4:
                item.setSubIcon1(null);
                item.setSubIcon2(it);
                item.setSubIcon3(it);
                item.setSubIcon4(it);
                item.setSubIcon5(it);
                break;

            default:
                item.setSubIcon1(it);
                item.setSubIcon2(it);
                item.setSubIcon3(it);
                item.setSubIcon4(it);
                item.setSubIcon5(it);
            break;

        }

        listViewItemList.add(item);
    }
}