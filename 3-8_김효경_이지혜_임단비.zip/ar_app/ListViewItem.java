package com.wikitude.samples;

import android.graphics.drawable.Drawable;

/**
 * Created by KDH on 2017-08-17.
 */

public class ListViewItem
{
    private Drawable iconDrawable, subIcon1, subIcon2, subIcon3, subIcon4, subIcon5;
    private String titleStr;

    public void setIcon(Drawable icon)
    {
        iconDrawable = icon;
    }

    public void setSubIcon1(Drawable icon)
    {
        subIcon1 = icon;
    }
    public void setSubIcon2(Drawable icon)
    {
        subIcon2 = icon;
    }
    public void setSubIcon3(Drawable icon)
    {
        subIcon3 = icon;
    }
    public void setSubIcon4(Drawable icon)
    {
        subIcon4 = icon;
    }
    public void setSubIcon5(Drawable icon)
    {
        subIcon5 = icon;
    }

    public void setTitle(String title)
    {
        titleStr = title;
    }

    public Drawable getIcon()
    {
        return this.iconDrawable;
    }

    public Drawable getSubIcon1()
    {
        return this.subIcon1;
    }
    public Drawable getSubIcon2()
    {
        return this.subIcon2;
    }
    public Drawable getSubIcon3()
    {
        return this.subIcon3;
    }
    public Drawable getSubIcon4()
    {
        return this.subIcon4;
    }
    public Drawable getSubIcon5()
    {
        return this.subIcon5;
    }

    public String getTitle()
{
    return this.titleStr;
}
}