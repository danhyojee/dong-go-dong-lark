<?php  

$db_host = "localhost"; 
 $db_user = "eksql2148"; 
 $db_passwd = "zookebox13"; 
 $db_name = "eksql2148"; 
 $conn = mysqli_connect($db_host,$db_user,$db_passwd,$db_name); 
 if (mysqli_connect_errno($conn)){ 
    echo "DB ACCESS FAIL". mysqli_connect_errno(); 
 } 




$sql="select * from Animal";

$result=mysqli_query($conn,$sql);
$data = array();   
if($result){  
    
    while($row=mysqli_fetch_array($result)){
        array_push($data, 
            array('id'=>$row[0],
            'name'=>$row[1],
            'status'=>$row[2],
            'puzzle'=>$row[3]
        ));
    }

header('Content-Type: application/json; charset=utf8');
$json = json_encode(array("webnautes"=>$data), JSON_PRETTY_PRINT+JSON_UNESCAPED_UNICODE);
echo $json;

}  
else{  
    echo "Error Processing SQL sentence : "; 
    echo mysqli_error($conn );
} 


 
mysqli_close($conn);  
   
?>