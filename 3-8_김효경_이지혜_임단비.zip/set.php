<?php

$db_host = "localhost"; 
 $db_user = "eksql2148"; 
 $db_passwd = "zookebox13"; 
 $db_name = "eksql2148"; 

$name=$_GET["name"];

 $conn = mysqli_connect($db_host,$db_user,$db_passwd,$db_name); 
 if (mysqli_connect_errno($conn)){ 
    echo "DB ACCESS FAIL". mysqli_connect_errno(); 
 } 

$sql = "UPDATE Animal SET number = 0 WHERE name =  '".$name."'";
$sql2 = "UPDATE Animal SET status = 1 WHERE name =  '".$name."'";

mysqli_query($conn,$sql);
mysqli_query($conn,$sql2); 

mysqli_close($conn);
?>

