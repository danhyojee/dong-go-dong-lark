<html>
<body>
<strong>Get <?php echo $_GET["animal"]; ?> puzzle!</strong> <br><br>
<?php
$get_name= $_GET["animal"];
$db_host = "localhost"; 
 $db_user = "eksql2148"; 
 $db_passwd = "zookebox13"; 
 $db_name = "eksql2148"; 
 $conn = mysqli_connect($db_host,$db_user,$db_passwd,$db_name); 
 if (mysqli_connect_errno($conn)){ 
    echo "DB ACCESS FAIL". mysqli_connect_errno(); 
 } else { echo"DB ACCESS SUCCESS"; }
?>
<br><br>
<?php

$query="UPDATE Animal SET number = number+1 WHERE user_name =  '".$get_name."'"



$result = mysqli_query($conn,$query); 
 


//database all data get
//$result = mysqli_query($conn,"SELECT * FROM Animal ");
//while($row = mysqli_fetch_array($result)){ 
//echo $row['name'];
//echo "<br>";
//}

mysqli_close($conn);
?>
</body>
</html> 

